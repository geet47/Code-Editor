
# Code-Editor

Code-Editor project Using ( HTML,CSS,JavaScript)


# How to Run

How to run the Code-Editor project.
1. Download the zip file
2. Extract the file 
3. Open the Code-Editor folder
4. Choese the index file
5. index file open the any Browser

Thank you !!